"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios = require('axios').default;
const blobTrigger = function (context, myBlob) {
    return __awaiter(this, void 0, void 0, function* () {
        context.log("Blob trigger function processed blob \n Name:", context.bindingData.name, "\n Blob Size:", myBlob.length, "Bytes");
        const documentsArr = myBlob.toString().match(/(.{1,5120})/gs);
        const documents = documentsArr.map((d, index) => ({
            text: d,
            id: index + 1,
            language: "en",
            isLanguageDefaulted: true,
            isLanguageFinalized: false,
            isAutoLanguageDetectionEnabled: false
        }));
        const structuringEndpoint = process.env.TA_FHIR_STRUCTURING_ENDPOINT;
        const config = {
            headers: { 'content-Type': 'application/json' },
            params: { structureFHIR: true }
        };
        // const data = {body: { documents: documents }};
        let fhirDocs = [];
        const data = { "documents": documents };
        try {
            const resp = yield axios.post(structuringEndpoint, data, config);
            context.log(resp);
            fhirDocs = resp.data.documents.map(d => JSON.parse(d.fhirBundle));
        }
        catch (err) {
            context.log(err);
            throw err;
        }
        context.log(fhirDocs);
        if (fhirDocs.length == 0) {
            context.done();
            return;
        }
        context.bindings.outputBlob = JSON.stringify(fhirDocs[0], null, 4);
        context.res = {
            // status: 200, /* Defaults to 200 */
            body: fhirDocs[0]
        };
    });
};
exports.default = blobTrigger;
//# sourceMappingURL=index.js.map