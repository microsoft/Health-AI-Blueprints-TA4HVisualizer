import { AzureFunction, Context } from "@azure/functions";
const axios = require('axios').default;


const blobTrigger: AzureFunction = async function (context: Context, myBlob: any): Promise<void> {
    context.done();
    return;
}

export default blobTrigger;
